package com.miempresa.api.controllers;

import com.miempresa.api.models.Producto;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    private List<Producto> productos = new ArrayList<>();
    private Long nextId = 1L;

    // Constructor: cargamos algunos productos de ejemplo
    public ProductoController() {
        productos.add(new Producto(nextId++, "Laptop", 2500.00));
        productos.add(new Producto(nextId++, "Mouse", 45.00));
        productos.add(new Producto(nextId++, "Teclado", 120.00));
    }

    // GET /api/productos — listar todos
    @GetMapping
    public List<Producto> listar() {
        return productos;
    }

    // GET /api/productos/{id} — obtener uno por id
    @GetMapping("/{id}")
    public Producto obtener(@PathVariable Long id) {
        return productos.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    // POST /api/productos — crear nuevo
    @PostMapping
    public Producto crear(@RequestBody Producto producto) {
        producto.setId(nextId++);
        productos.add(producto);
        return producto;
    }

    // PUT /api/productos/{id} — actualizar existente
    @PutMapping("/{id}")
    public Producto actualizar(@PathVariable Long id, @RequestBody Producto producto) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) {
                p.setNombre(producto.getNombre());
                p.setPrecio(producto.getPrecio());
                return p;
            }
        }
        return null;
    }

    // DELETE /api/productos/{id} — eliminar
    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable Long id) {
        boolean removed = productos.removeIf(p -> p.getId().equals(id));
        if (removed) {
            return "Producto eliminado correctamente";
        }
        return "Producto no encontrado";
    }
}
